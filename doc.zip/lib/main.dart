import 'package:flutter/material.dart';

import 'screen/type1.dart';
import 'screen/type2.dart';

void main() {
  runApp(new MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
        title: 'hôtelerie',
        theme: new ThemeData(primarySwatch: Colors.blueGrey),
        debugShowCheckedModeBanner: false,
        home: Type1(),
        routes: {
          'type2': (context) => Type2(),
        });
  }
}
