import 'package:flutter/services.dart' show rootBundle;
import 'dart:convert';

class Categorietype {
  int id;
  String nom;
  List<Produittype> produit;

  Categorietype({this.id, this.nom, this.produit});

  Categorietype.fromJson(Map<String, dynamic> json) {
    id = json["id"];
    nom = json["nom"];

    if (json["produit"] != null) {
      produit = List<Produittype>();
      json["produit"].forEach((v) {
        produit.add(Produittype.fromJson(v));
      });
    }
  }

  Future<String> chargerJson() async {
    return await rootBundle.loadString("assets/data2.json");
  }

  Future loadchargerJson() async {
    final charge = await chargerJson();
    Iterable response = json.decode(charge);

    List<Categorietype> arr =
        response.map((i) => Categorietype.fromJson(i)).toList();
    return arr;
  }
}

class Produittype {
  int id, prix;
  String nom, description, image;

  Produittype({this.id, this.nom, this.description, this.prix, this.image});

  Produittype.fromJson(Map<String, dynamic> json) {
    id = json["id"];
    nom = json["nom"];
    description = json["description"];
    prix = json["prix"];
    image = json["image"];
  }
  Future<String> chargerJson() async {
    return await rootBundle.loadString("assets/data2.json");
  }

  Future loadchargerJson1() async {
    final charge = await chargerJson();
    Iterable response = json.decode(charge);

    List<Produittype> arr =
        response.map((i) => Produittype.fromJson(i)).toList();
    return arr;
  }
}
