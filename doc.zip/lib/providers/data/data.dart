// Pour les appeler directirectement dans notre fichier, o fait:
// "nom": type1Data[i]["nameData"],
// "nom": type2Data[i]["imgData"],

List type1Data = [
  {
    "imgData": "images/maison23.png",
    "nameData": "Ibiza Hôtel",
    "etoilData": "5",
    "sounameData": "haut de gamme",
    "prixData": "\$700 la nuit",
  },
  {
    "imgData": "images/maison19.png",
    "nameData": "Hôtel Ivoire",
    "etoilData": "5",
    "sounameData": "le luxe",
    "prixData": "\$650 la nuit",
  },
  {
    "imgData": "images/maison21.png",
    "nameData": "Palme Club",
    "etoilData": "4",
    "sounameData": "cadre paisible",
    "prixData": "\$450 la nuit",
  },
  {
    "imgData": "images/maison24.png",
    "nameData": "Paradis Hôtel",
    "etoilData": "5",
    "sounameData": "cadre luxieux",
    "prixData": "\$1000 la nuit",
  },
];

List type2Data = [
  {
    "imgData": "images/maison23.png",
    "p1Data": "images/maison18.png",
    "p2Data": "images/maison13.png",
    "p3Data": "images/maison11.png",
    "p4Data": "images/maison5.png",
    "nameData": "Ibiza Hôtel",
    "etoilData": "5",
    "sounameData": "haut de gamme",
    "prixData": "\$700 la nuit",
    "desData":
        "Un cadre calme, luxieux pour vos cérémonies privés, des suites de ouf...",
  },
  {
    "imgData": "images/maison19.png",
    "p1Data": "images/maison1.png",
    "p2Data": "images/maison2.png",
    "p3Data": "images/maison11.png",
    "p4Data": "images/maison18.png",
    "nameData": "Hôtel Ivoire",
    "etoilData": "5",
    "sounameData": "le luxe",
    "prixData": "\$650 la nuit",
    "desData":
        "Envie de gôuter au luxe, venez vous amusez dans un endroit très privé",
  },
  {
    "imgData": "images/maison21.png",
    "p1Data": "images/maison15.png",
    "p2Data": "images/maison18.png",
    "p3Data": "images/maison13.png",
    "p4Data": "images/maison11.png",
    "nameData": "Palme Club Hôtel",
    "etoilData": "4",
    "sounameData": "cadre paisible",
    "prixData": "\$450 la nuit",
    "desData":
        "Envie de gôuter au luxe, venez vous détendre dans un endroit discret",
  },
  {
    "imgData": "images/maison24.png",
    "p1Data": "images/maison1.png",
    "p2Data": "images/maison15.png",
    "p3Data": "images/maison2.png",
    "p4Data": "images/maison5.png",
    "nameData": "Paradis Hôtel",
    "etoilData": "5",
    "sounameData": "cadre luxieux",
    "prixData": "\$1000 la nuit",
    "desData":
        "luxe, plaisir, détente, venez découvrir un cadre à vous coupez le soufle!",
  },
];

List recomData = [
  {
    "imgData": "images/maison22.png",
    "etoilData": "5",
  },
  {
    "imgData": "images/maison25.png",
    "etoilData": "5",
  },
  {
    "imgData": "images/maison21.png",
    "etoilData": "4",
  },
  {
    "imgData": "images/maison24.png",
    "etoilData": "5",
  },
  {
    "imgData": "images/maison19.png",
    "etoilData": "5",
  },
  {
    "imgData": "images/maison23.png",
    "etoilData": "4",
  },
];

List type2pData = [
  {
    "imgData": "images/maison1.png",
  },
  {
    "imgData": "images/maison2.png",
  },
  {
    "imgData": "images/maison11.png",
  },
  {
    "imgData": "images/maison18.png",
  },
];
