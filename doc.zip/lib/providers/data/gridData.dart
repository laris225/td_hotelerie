List gridData = [
  {
    'image': "images/chair.png",
    'name': "Nath's Chair",
    'price': "\$680",
    "description": "A modern take on tradition",
  },
  {
    'image': "images/chairA.png",
    'name': 'Cedric Chair',
    'price': "\$580",
    "description": "A modern take on tradition",
  },
  {
    'image': "images/chairB.png",
    'name': 'Domi Chair',
    'price': "\$680",
    "description": "A modern take on tradition",
  },
  {
    'image': "images/chairC.png",
    'name': 'Sydney Chair',
    'price': "\$770",
    "description": "A modern take on tradition",
  },
  {
    'image': "images/chairD.png",
    'name': 'Davy Chair',
    'price': "\$300",
    "description": "A modern take on tradition",
  },
  {
    'image': "images/chairZ.png",
    'name': 'Domi Chair',
    'price': "\$950",
    "description": "A modern take on tradition",
  },
];
